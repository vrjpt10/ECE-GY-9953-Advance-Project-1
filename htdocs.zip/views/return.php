<?php 

require __DIR__ . '/header.php'; 
require __DIR__ . '/db.php'; 

if(!isset($_SESSION['name'])) {
    header('Location: /login');
}

if(!isset($_GET['id'])) {
    header('Location: /profile');
}

//$details;
//$statement = $pdo->prepare("SELECT * FROM transactions WHERE id=? AND email=?");
//$statement->execute(array(filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT), $_SESSION['email']));
$statement = $pdo->prepare("UPDATE transactions SET is_return=?, timestamp=? WHERE id=? AND email=?");
$statement->execute(array(1, date("Y-m-d h:i:sa"), filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT),  $_SESSION['email']));
header('Location: /orders');
?>
<?php require __DIR__ . '/footer.php'; ?>